# 本地环境：C2 数据库 → C3 私有存储 → C8 隔离评估

这些文件只准备基础设施，产品代码仍由你逐课实现。镜像固定为 PostgreSQL 17 + pgvector 0.8.6、Garage 2.4.1；存储检查复用 C3 的 S3 SDK，不需要另装 S3 命令行工具。C1 不需要启动任何服务。

## 1. Windows 先准备 Docker

Docker 负责启动本指南配好的数据库和存储服务，不要求现在学习镜像制作。先做三项检查，再下载安装：

1. Windows 按 Win+R，输入 `winver`，记下系统版本；在「设置 → 系统 → 系统信息」查看处理器与内存，对照 [Docker 官方安装要求](https://docs.docker.com/desktop/setup/install/windows-install/)。不要把“能打开安装器”当成系统一定兼容。
2. 按 Ctrl+Shift+Esc 打开任务管理器，进入「性能 → CPU」，查看“虚拟化”是否已启用。这是查看状态，不修改系统；未启用、设备受学校／公司管理或没有所需权限时，先联系设备管理者或按设备厂商的官方说明处理。没有通用于所有电脑的 BIOS 操作步骤，课程不要求盲改。
3. 在普通 PowerShell 运行 `wsl --version`、`wsl --status`，对照官方要求。提示需要更新时，在开始菜单右键 PowerShell →「以管理员身份运行」，执行 `wsl --update`；尚未安装则按[微软 WSL 安装说明](https://learn.microsoft.com/en-us/windows/wsl/install)执行 `wsl --install --no-distribution`。完成要求的重启后重新检查。失败就记录错误类别，不反复安装、不删发行版。

系统条件满足后安装 [Docker Desktop](https://docs.docker.com/desktop/setup/install/windows-install/)，选择 WSL 2 后端，使用 Linux containers。按安装器要求重启，从开始菜单打开 Docker Desktop，等引擎就绪。在**新的普通 PowerShell** 验证：

```powershell
wsl --version
wsl --status
docker version
docker compose version
node --version
```

`docker version` 必须同时有 Client 和 Server；只有 Client 时先启动引擎。Node 要 >=20.19。macOS/Linux 使用 Docker Desktop 或 Docker Engine + Compose v2，后续 `node` 和 `docker compose` 命令相同；只有下文的环境变量语法区分 shell。

**安装成功标志：**WSL 满足当前官方最低版本，Docker 有 Server、Compose 有版本号、Node 符合要求。重启只完成一部分时，回到这组只读检查，不重复生成项目配置。若虚拟化／WSL／权限仍阻断，可以先完成产品文档；环境、数据库与后续验收保持未完成。Stage 3 的单云数据库方案不能替代 Capstone 的数据库、Garage 与 Eval 隔离边界。

Windows 跟课用 Linux 容器里的 pgvector，避免在 Windows PostgreSQL 上现场编译扩展。若已有原生 PostgreSQL，也先按这套独立容器完成课程；不要把数据库 URL 指向课程平台或已有业务库。

## 2. C2：启动独立开发库和测试库

在解压后的 starter 根目录执行（已有项目只补入本指南、compose.yaml、infra/ 和 scripts/ 中的两个环境脚本，保留自己的代码和文档）：

```powershell
node scripts/init-local-env.mjs
docker compose --env-file .env.local up -d --wait db eval-db
docker compose --env-file .env.local ps
docker compose --env-file .env.local exec -T db pg_isready -U capstone -d capstone
docker compose --env-file .env.local exec -T eval-db pg_isready -U capstone -d capstone_c8_eval
docker compose --env-file .env.local exec -T db psql -U capstone -d capstone -c "SELECT name, default_version FROM pg_available_extensions WHERE name='vector';"
```

两库都应 healthy / accepting connections；最后应返回 `vector | 0.8.6`。镜像包含扩展文件，C2 尚不启用向量功能。C3 的正式 migration 才执行 `CREATE EXTENSION IF NOT EXISTS vector` 并建 `vector(1024)` 列。

初始化脚本生成随机本地密码、S3 key 和 Garage RPC secret，只写被 Git 忽略的 `.env.local`，不打印值；再次执行会保留现有文件。`.env.example` 是变量说明，不含可用凭据。Next.js 自动读取 `.env.local`；Compose 每次都显式指定 `--env-file .env.local`。Prisma CLI 不会自动读取这个 Next.js 文件，安装 Prisma 后用 Node 显式加载：

```powershell
node --env-file=.env.local node_modules/prisma/build/index.js migrate dev --name init
node --env-file=.env.local node_modules/prisma/build/index.js migrate status
npm run dev
```

上面的 `migrate dev` 用于 C2 创建开发迁移，需要先完成本课 schema。测试库只部署已写好的迁移。日常窗口 A 保持开发服务；另开测试窗口 B，重新 `cd` 到同一 Capstone 根目录，确认 `package.json`、`compose.yaml` 都存在。在 B 执行下面的 PowerShell 命令切换测试环境，再运行测试（替换成你项目中已实现的测试命令）：

```powershell
$env:TEST_DATABASE_URL = node --env-file=.env.local -p 'process.env.TEST_DATABASE_URL'
$env:DATABASE_URL = $env:TEST_DATABASE_URL
node node_modules/prisma/build/index.js migrate deploy
npm test
```

macOS/Linux 的测试窗口对应命令：

```bash
export TEST_DATABASE_URL=$(node --env-file=.env.local -p 'process.env.TEST_DATABASE_URL')
export DATABASE_URL="$TEST_DATABASE_URL"
node node_modules/prisma/build/index.js migrate deploy
npm test
```

测试完关闭这个窗口。不要在它里面启动日常开发服务。开发用 `127.0.0.1:55439/capstone`；测试用 `127.0.0.1:55440/capstone_c8_eval?schema=public`，是独立 PostgreSQL 服务和数据卷。测试 runner 必须核对 host、port、database、schema 和 `DATABASE_URL === TEST_DATABASE_URL`；复制旧阶段的 guard 时只把明确的本地 allowlist 改为此测试地址，保留其他拒绝规则。

## 3. C3：启动 Garage 并验证私有性与 CORS

```powershell
docker compose --env-file .env.local up -d garage
docker compose --env-file .env.local exec -T garage /garage status
docker compose --env-file .env.local exec -T garage /garage bucket info capstone-private
npm install --save-exact @aws-sdk/client-s3@3.1147.0 @aws-sdk/s3-request-presigner@3.1147.0
node scripts/check-local-storage.mjs
```

Garage 通过 `--single-node --default-bucket` 自动建立单节点布局、私有 bucket 和关联 key，不需要手工猜 Node ID 或运行 layout assign。应看到健康节点、bucket 存在。刚启动时尚未就绪可稍等再执行 status。

先安装固定版本的两个 S3 SDK 包，这是 C3 存储 adapter 本就需要的依赖。检查脚本只用于本地基础设施，配置 CORS、上传一份无敏感信息的 TXT、验证 signed GET、验证匿名 GET 被拒、验证 PUT preflight；只输出 PASS，不打印密钥和签名 URL。它保留 `aifoundry-infra-check/storage-check.txt` 这个合成对象，重复运行覆盖同一个检查对象。

`.env.local` 中 `S3_ENDPOINT=http://127.0.0.1:3900`、region 为 `garage`、bucket 为 `capstone-private`。应用 adapter 必须使用 path style。开发服务在宿主机运行，端点必须是浏览器能访问的地址；不要把 Compose 内的 `http://garage:3900` 填进应用签名 URL。Secret 只在服务端。

默认应用来源是 `http://localhost:3000`，`infra/cors.json` 同时列出 `http://127.0.0.1:3000`。换端口时手工同步 `C3_APP_ORIGIN` 与 CORS 的 AllowedOrigins，再运行检查；不要改成 `*`。命令行 preflight 通过后，仍需在 C3 页面真正上传 TXT，观察浏览器 Network 中 OPTIONS/PUT 成功，以及处理后状态 READY。CORS 控制浏览器访问，不能代替 bucket 的签名鉴权。

随后完成 C3 migration，在开发库检查扩展已启用：

```powershell
docker compose --env-file .env.local exec -T db psql -U capstone -d capstone -c "SELECT extname, extversion FROM pg_extension WHERE extname='vector';"
```

再按本课验证 1024 维检索、Alice/Bob 隔离和失败重试。基础设施检查不能证明你的上传路由、文件处理或 ownership 已正确。

## 4. C2～C7：运行本机 HTTP 验收

HTTP 检查需要一个已经启动、连接隔离库的应用。日常窗口 A 可以继续跑开发服务。另开两个项目终端 B 和 C，分别进入这个项目根目录，按第 2 节的系统命令把两个数据库变量都指向 `capstone_c8_eval`。在 C 部署迁移并核对：

```bash
npx prisma migrate deploy
npx prisma migrate status
```

C3 起如需真实上传，先按第 3 节启动 Garage。把测试应用本课用到的各项 `AI_*_MODE` 设为 `mock`。如果本课测试本身不负责注入故障，先在 B 按该课的测试配置设好所需开关。沿参考命名时，C3 用 `C3_EMBED_FAIL_ONCE_AT=1` 验证失败后重试，C4 用 `C4_MOCK_TEST_SCENARIOS=1`，C5 用 `C5_MOCK_TEST_SCENARIOS=1`。这些开关按课使用，C3 的一次性故障要在该用例前启动新的测试应用进程。C6、C7 先完成本节下方各自的配置，再启动测试应用。下面以端口 3118 为例，在 B 运行：

```bash
npm run dev -- --hostname 127.0.0.1 --port 3118
```

进入浏览器核对 B 的实际首页可打开。C 中设置测试脚本使用的 URL，再运行本课已实现的 `test:db`。C6 先确保下文的 MCP 替身已经启动：

```powershell
$env:CAPSTONE_BASE_URL = 'http://127.0.0.1:3118'
npm run test:db
```

```bash
export CAPSTONE_BASE_URL=http://127.0.0.1:3118
npm run test:db
```

B 的启动端口和 C 的请求目标要一致。若用 B 的浏览器做上传（示例为 3118），按第 3 节将该来源加入 `infra/cors.json` 并重跑 `node scripts/check-local-storage.mjs`；日常 A 的上传仍可走原 3000 端口。故障开关仅在本机测试窗口设置，PowerShell 使用 `$env:变量名 = '1'`，macOS/Linux 使用 `export 变量名=1`。验收结束后在 B 按 Ctrl+C，只关闭本轮测试用服务。

**C6 的 MCP 测试替身。** 先在本机 `.env.local` 设置独立随机的 `MCP_EXTERNAL_AUTH_SECRET`，测试应用与替身用同一个值。运行 `node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"` 生成随机值，由你本人在本机填写。C6 的测试应用配置 `MCP_EXTERNAL_URL=http://127.0.0.1:3133/api/mcp/external-research`，把 `MCP_ALLOW_LOCAL_HTTP` 设为 `1`。保存后启动 B；若 B 已运行，则停止后重新启动。另开终端 D，进项目根目录，用对应系统的方式为 D 设置 `C6_TEST_MCP_FIXTURE=1`：

```powershell
$env:C6_TEST_MCP_FIXTURE = '1'
node --env-file=.env.local --import tsx scripts/c6-mcp-fixture.ts
```

```bash
export C6_TEST_MCP_FIXTURE=1
node --env-file=.env.local --import tsx scripts/c6-mcp-fixture.ts
```

等替身显示已在 3133 监听，再从 C 运行 `npm run test:db`。结束后在 D 按 Ctrl+C。验证真实外部链路前，将独立验证应用的 `MCP_EXTERNAL_URL` 指回**实际应用自身**的 `/api/mcp/external-research` 并重启。

**C7 的确认测试。** 另外生成一个独立的随机 `ACTION_APPROVAL_SECRET`，在本机配置中填写。应用和直接验证 Token 的测试都需要能读取同一个值；让 C7 的 `test:db` 从本机配置加载 `ACTION_APPROVAL_SECRET` 并继承 C 的数据库与地址变量。沿用参考文件名时，可在独立终端用 `node --env-file=.env.local scripts/c7-http-smoke.mjs` 与 `node --env-file=.env.local --import tsx --test test/knowledge-write.integration.ts` 分别核对 HTTP 和事务。继续使用隔离库和本机 Mock，按你实现的 C7 用例决定是否保留 C6 的测试替身。

## 5. C8：复用隔离 Eval 库

`eval-db` 的 55440 端口与 C8 的严格 allowlist 对齐。默认数据库是 `capstone_c8_eval`；首次初始化还创建 `capstone_c8_real`，供可选真实模型评估。二者都与日常开发库分离。运行前在独立测试窗口设置第 2 节的两个数据库变量，部署全部已提交 migration，运行 `npm run build`，再执行 C8 注册的 `npm run eval:capstone`（`tsx eval/runner.mjs`）。完成首次全量评估并审核 `eval/baseline.json` 后，用 `npm run eval:capstone -- --compare-baseline eval/baseline.json` 复验。单条故障注入使用 C8 正文的固定 case ID 和 `--` 参数分隔符。默认评估脚本会启动自己的测试应用。准备好评估器约定的端口，作者参考实现使用 3142（应用）和 3911（私有存储替身）；如果已被自己的其他验证进程占用，先停掉那一轮。

仅在选择真实评估时，打开新的专用终端，先按第 2 节设置测试变量，再用下面对应的两行把两个变量同时换到 `capstone_c8_real`。命令只改当前终端，不显示连接串：

```powershell
$env:TEST_DATABASE_URL = $env:TEST_DATABASE_URL -replace '/capstone_c8_eval(?=\?|$)', '/capstone_c8_real'
$env:DATABASE_URL = $env:TEST_DATABASE_URL
```

```bash
export TEST_DATABASE_URL="$(node -p 'const u = new URL(process.env.TEST_DATABASE_URL); u.pathname = "/capstone_c8_real"; u.toString()')"
export DATABASE_URL="$TEST_DATABASE_URL"
```

重新运行 `npx prisma migrate deploy` 和 `npx prisma migrate status`，确认输出目标库是 `capstone_c8_real`。准备实际 Chat 与 1024 维 Embedding 的服务端 Base URL、Key 和模型名，再在此终端选择执行：

```powershell
$env:C8_REAL_EVAL = '1'
npm run eval:capstone:real
```

```bash
export C8_REAL_EVAL=1
npm run eval:capstone:real
```

直接运行 npm 入口时需要让 Runner 进程自己能读到 Provider 配置。若配置只在本机 `.env.local` 中，用 `node --env-file=.env.local --import tsx eval/runner.mjs --real` 代替上面的 npm 命令，已设置的隔离库和启用变量仍优先。验证后关闭此终端。普通确定性评估使用另一个终端，保持 Mock。

## 6. 停止与排错

暂停课程时执行 `docker compose --env-file .env.local stop db eval-db garage`；恢复时执行相应的 `up -d`。named volumes 保留数据与凭据。不要重新生成密码来修连接错误，也不要删除数据卷来排错。

| 症状 | 先检查 |
|---|---|
| docker 无 Server / WSL 失败 | Docker Desktop、WSL 2、Linux containers；按官方安装文档排错 |
| 端口被占用 | 55439、55440、3900 的占用进程；不要停掉不认识的服务，修改端口需同步 URL 与测试 allowlist |
| 镜像拉取失败 | Docker 网络/代理与官方 registry；不要让 AI 随意换第三方镜像 |
| authentication failed | `.env.local` 是否与首次创建数据卷时的密码一致；初始化脚本保留旧文件 |
| vector 不在 available extensions | 是否真的连接了 pgvector 镜像；不要误连 Windows 原生 PostgreSQL |
| vector 未出现在 pg_extension | C3 migration 是否在这个数据库正式执行 |
| Garage 不健康 / bucket 不存在 | `/garage status`、启动 flags、配置文件挂载、持久卷；不要把 bucket 改公开 |
| storage checker 失败 | Garage 就绪、S3 SDK 安装、凭据与 bucket、CORS 的 origin/端口；不要分享原始 secret |
| CLI 检查过了但浏览器 PUT 失败 | 浏览器实际 Origin、preflight、path style、签名中的 host/Content-Type/过期时间 |

已有 `.env.local` 的项目：先在本地编辑器对照 `.env.example` 补缺失变量，生成新的随机值可用 `node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"`，只用于**尚未初始化**的服务。已有 DB/Garage 必须沿用原凭据。需要重建或批量清理时由你确认并手动处理，课程脚本不删除文件、目录或卷。

安装依据：[pgvector 官方安装说明](https://github.com/pgvector/pgvector#installation)、[Garage Quick Start](https://garagehq.deuxfleurs.fr/documentation/quick-start/)、[Garage 配置](https://garagehq.deuxfleurs.fr/documentation/reference-manual/configuration/)。版本锁定是为了复现实操；它不代表这套单节点环境已经适合生产。
