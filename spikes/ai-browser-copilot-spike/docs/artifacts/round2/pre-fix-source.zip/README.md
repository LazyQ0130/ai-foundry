# AI 网页阅读与知识整理助手：Phase 0 Spike

状态：**未发布；Phase 0 NO-GO，真实 Side Panel / activeTab / 右键 / 扩展网络链路尚待验证。**

本目录是独立技术原型，不是 P1–P8 Reference 或学员 Starter。只包含三个验证操作：读取当前网页、接收右键选区、调用本机 Mock 摘要。完整结论见 [技术验证报告](docs/evidence.md)，架构和限制见 [决策记录](docs/decisions.md)。

## 环境与安装

已验证 Windows、Node **24.16.0**、npm **11.13.0**；WXT **0.21.4** 要求 Node >=22，不能直接沿用主仓库 Node 20.19 的最低要求。Chrome 实际加载版本 **155.0.8059.41**，manifest 的最低版本是 116；116 上的兼容性尚未实测。

在本目录运行，勿在 AI Foundry 根目录安装这些依赖：

```powershell
npm ci
npm run typecheck
npm test
npm run build
npm run zip
```

加载目录为本目录下 `.output/chrome-mv3`，ZIP 为 `.output/ai-browser-copilot-phase0-0.0.0-chrome.zip`。本次从全新目录重建所得 ZIP 另保存在 `docs/artifacts/ai-browser-copilot-phase0-0.0.0-chrome.zip`，其 SHA256 见 `docs/artifacts/package-audit.json`。

无需批量删除任何文件。执行 `./scripts/rebuild.ps1` 会将明确列出的源文件复制到全新的 `.runtime/rebuild-时间戳`，从无依赖、无构建产物的状态运行全部检查并保留日志。脚本不删除旧目录；需要清理时请由用户手动处理。

## 最小手工复现（本轮未完成，不能当作通过证据）

1. 使用独立、未登录的 Chrome 测试 Profile。进入 `chrome://extensions`，开启开发者模式并加载上述 MV3 文件夹。
2. 打开普通 HTTPS 页面，例如 `https://example.com/`。从扩展菜单将本扩展固定到工具栏，然后点击扩展图标。
3. 在实际侧栏点击“读取当前网页”，确认标题、URL、正文和页面一致。侧栏按钮自身不产生新的 activeTab 授权。
4. 侧栏显示扩展 ID。在另一个终端启动本机 API（替换 ID）：

```powershell
$env:EXTENSION_ORIGIN='chrome-extension://替换为实际32位扩展ID'
$env:PROVIDER='mock'
npm run api
```

5. 检查 `http://127.0.0.1:8787/health`，再在侧栏点击“调用本机 Mock 摘要”，确认出现 `[MOCK]` 和输入字符数。**本轮只验证了服务端实际 HTTP 请求，扩展 fetch 的 CORS/本地网络权限行为仍待实测。**
6. 在网页选中文字，右键选择“验证：发送选中文字到阅读侧栏”，点击“接收右键选区”。在第二个 HTTPS 站点（如 `https://www.iana.org/help/example-domains`）重复操作，并记录两个站点的 URL、tabId、选区和截图。不要用同源两个标签页替代两个站点。
7. 切换到未授权标签页、跨源导航、打开新标签页/`chrome://version`；应提示重新授权或不支持。切换期间旧读取/摘要不得覆盖新页。关闭标签页、空选区和 >2000 字符选区应拒绝。
8. 停止本机 API，应显示可恢复的网络错误；使用受控测试代理注入慢响应/非法 JSON，验证 2.5 秒客户端超时和格式错误。服务端单独有 1.8 秒 Provider 超时。
9. 正常退出并重开测试 Chrome，重新从图标授权、读取、选区、Mock；最后在第二个全新 Profile 复验。证据未齐全前保持 NO-GO。

可选的本地 fixture（只用于受控测试；不能替代两个真实 HTTPS 站点）：

```powershell
python -m http.server 8001 --bind 127.0.0.1 --directory tests/fixtures
```

分别访问 `http://127.0.0.1:8001/article-a.html` 与 `http://localhost:8001/article-b.html`，形成两个 origin。A 含隐藏内容、表单和恶意指令测试文本。

## 权限、数据与限制

- 只申请 `activeTab`、`scripting`、`sidePanel`、`contextMenus`、`storage`；无永久 host_permissions、常驻 content script 或 popup。
- 只注入顶层只读函数，读取可见文本，排除表单、隐藏节点、导航等；最多 6000 字符。不是 Readability 或完整网页解析器，浏览器抽取效果待验证。
- 后台校验扩展消息来源/格式和 tabId/URL，读取前后复查当前页。侧栏切页清空结果并取消 fetch；过期异步响应不应更新界面，尚需真实竞态测试。
- 右键文本限 2000 字符；仅用 `storage.session` 暂存（最多 60 秒、一次消费），切页失效，不持久保存浏览历史或全文。没有笔记功能。
- API 只监听 `127.0.0.1:8787`，校验精确扩展 Origin、Host、JSON schema、长度、速率、Provider 超时和响应格式。Origin 校验用于浏览器请求来源防护，不能替代公开服务鉴权，也不能阻止本地进程伪造头。
- 目前用标准 CORS，不申请后端 host 权限；Chrome 的实际 Origin/本地网络访问行为未确认。若失败，先记录真实请求头/错误，再验证最窄回环 host 权限方案，绝不加入全站权限。
- `api/.env.example` 只提供模板，服务不会自动加载 `.env`。当前只支持 Mock，不读取模型密钥。真实 Provider 只有可替换接口和变量约定，没有费用调用或兼容性成功声明。
- 不支持 PDF、iframe、深层 Shadow DOM、登录墙或网站自动操作。无 RAG、聊天、持久笔记、账号或平台接入。

## 自动化与交付说明

`npm test` 的 6 项测试使用真实回环 HTTP 服务，覆盖正常返回、预检、Origin/Host 拒绝、输入限制、速率、超时和非法 Provider 响应；纯函数断言只辅助检查消息和上下文身份，不能证明 Chrome 行为。

`npm run browser:launch` 是可选教师调试脚本：启动独立 Profile 的已安装 Chrome，通过 CDP `Extensions.loadUnpacked` 加载扩展。调试端口和 `--enable-unsafe-extension-debugging` 仅用于本机隔离测试，不是学员安装要求，不可用于日常浏览。它只证明加载，不代表图标/侧栏/授权已通过。本轮在 Windows 界面工具阻断后，没有继续以 CDP 触发 action 或模拟右键。

未修改 AI Foundry 的课程、权限、价格、发布状态或数据库。当前代码在 `main` 下的独立新增目录，未创建提交、未推送、未发布。依赖版本由本目录 lockfile 固定；许可证及官方资料见决策记录。
