import { defineBackground } from 'wxt/utils/define-background';
import { Request, Selection, SelectionSlot, MAX_TEXT, Snapshot, sameContext, supported } from '../../shared/contracts';
import { extractPage } from '../src/extract';

export default defineBackground(() => {
  const setup = () => chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);
  void setup();
  chrome.runtime.onStartup.addListener(setup);
  chrome.runtime.onInstalled.addListener(() => {
    void setup();
    chrome.contextMenus.create({ id: 'phase0-selection', title: '验证：发送选中文字到阅读侧栏', contexts: ['selection', 'page'] }, () => { void chrome.runtime.lastError; });
    void chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
  });
  chrome.tabs.onActivated.addListener(({ windowId }) => {
    void chrome.storage.session.remove(`selection:${windowId}`);
  });
  chrome.tabs.onUpdated.addListener((_id, change, tab) => {
    if (change.status === 'loading' || change.url) void chrome.storage.session.remove(`selection:${tab.windowId}`);
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId !== 'phase0-selection' || !tab?.id) return;
    // Call open synchronously: awaiting storage/tabs first can lose the user gesture.
    const opened = chrome.sidePanel.open({ windowId: tab.windowId });
    void opened.catch(console.error);
    void (async () => {
      const key = `selection:${tab.windowId}`;
      await chrome.storage.session.remove(key);
      const parsed = Selection.safeParse({ tabId: tab.id, url: info.pageUrl, text: info.selectionText ?? '', createdAt: Date.now(), requestId: crypto.randomUUID() });
      const active = (await chrome.tabs.query({ active: true, windowId: tab.windowId }))[0];
      const current = await chrome.tabs.get(tab.id!);
      const valid = parsed.success && supported(parsed.data.url) && sameContext({ tabId: active?.id ?? -1, url: active?.url }, parsed.data) && sameContext({ tabId: current.id!, url: current.url }, parsed.data);
      await chrome.storage.session.set({ [key]: valid ? { ok: true, data: parsed.data } : { ok: false, message: '选区为空、超过 2000 字符或页面已变化，请重新选择。' } });
    })().catch(console.error);
  });
  chrome.runtime.onMessage.addListener((raw, sender, respond) => {
    const parsed = Request.safeParse(raw);
    if (sender.id !== chrome.runtime.id || sender.tab || sender.url !== chrome.runtime.getURL('sidepanel.html') || !parsed.success) {
      respond({ ok: false, requestId: '', code: 'BAD_MESSAGE', message: '消息来源或格式不正确。' }); return false;
    }
    const request = parsed.data;
    void (async () => {
      const fail = (code: string, message: string) => ({ ok: false, requestId: request.requestId, code, message });
      const tab = await chrome.tabs.get(request.context.tabId);
      const assertCurrent = async () => {
        const active = (await chrome.tabs.query({ active: true, windowId: tab.windowId }))[0];
        const current = await chrome.tabs.get(request.context.tabId);
        return sameContext({ tabId: active?.id ?? -1, url: active?.url }, request.context) && sameContext({ tabId: current.id!, url: current.url }, request.context);
      };
      if (!supported(request.context.url)) return fail('UNSUPPORTED_PAGE', '此页面不允许读取。请打开普通 HTTPS 网页。');
      if (!await assertCurrent()) return fail('TAB_CHANGED', '页面已切换，请点击扩展图标授权当前页。');
      if (request.type === 'TAKE_SELECTION') {
        const key = `selection:${tab.windowId}`;
        const slot = SelectionSlot.safeParse((await chrome.storage.session.get(key))[key]);
        const pending = slot.success ? slot.data : undefined;
        await chrome.storage.session.remove(key);
        if (!pending?.ok) return fail('NO_SELECTION', pending?.message ?? '没有有效选区，请重新选择。');
        const selection = Selection.safeParse(pending.data);
        if (!selection.success || Date.now() - selection.data.createdAt > 60000 || !sameContext(selection.data, request.context) || !await assertCurrent()) return fail('TAB_CHANGED', '选区已失效，请重新选择。');
        return { ok: true, requestId: request.requestId, data: selection.data };
      }
      try {
        const [result] = await chrome.scripting.executeScript({ target: { tabId: tab.id! }, func: extractPage, args: [MAX_TEXT] });
        if (!await assertCurrent() || result?.result?.url !== request.context.url) return fail('TAB_CHANGED', '读取期间页面已变化，结果已丢弃。');
        if (!result?.result?.text?.trim()) return fail('NO_CONTENT', '未找到可见正文。');
        const snapshot = Snapshot.parse({ ...result.result, tabId: tab.id!, snapshotId: crypto.randomUUID(), capturedAt: new Date().toISOString() });
        return { ok: true, requestId: request.requestId, data: snapshot };
      } catch { return fail('NEEDS_PERMISSION', '请点击浏览器工具栏的扩展图标，重新授权当前页。'); }
    })().then(respond).catch(() => respond({ ok: false, requestId: request.requestId, code: 'TAB_CHANGED', message: '标签页已关闭或不可访问，请重新授权。' }));
    return true;
  });
});
